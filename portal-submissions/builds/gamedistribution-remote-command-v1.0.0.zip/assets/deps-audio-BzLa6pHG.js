import{h as o}from"./vendor-audio-BBbuYe7m.js";window.Howl=o.Howl,window.Howler=o.Howler;
